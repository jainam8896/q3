const mongoose=require('mongoose')
const orderSchema=new mongoose.Schema({
    uname:{
        type:String,
        required:true,
    },
    phone:{
        type:Number,
        required:true,
    },
    order:{
        type:Array,
        required:true,
    },
})
module.exports=mongoose.model('order',orderSchema)