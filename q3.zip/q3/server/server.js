const express = require('express')
const mongoose=require('mongoose')
const app = express()
const itemRoutes = require('./routes/bill_route')
const orderRoutes = require('./routes/order_route')
const cors=require('cors')

mongoose.connect('mongodb://127.0.0.1:27017/student')
app.use(express.json())
app.use(cors())
app.use('/item',itemRoutes)
app.use('/order',orderRoutes)

app.listen(3004,()=>{
    console.log('server is running')
})