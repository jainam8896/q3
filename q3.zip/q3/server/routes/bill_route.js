const express = require('express')
const router = express.Router()
const getinfo = require('../models/bill_models')

router.post('/additem',async(req,res)=>{
    const ientry = new getinfo({
        name:req.body.name,
        price:req.body.price,
        qty:req.body.qty,
    })
    await ientry.save();
    res.send();
});

router.get('/dispitem',async(req,res)=>{
    const data = await getinfo.find();
    res.json(data);
});

router.get('/totalqty',async(req,res)=>{
    const result = await getinfo.aggregate([{
        $group:{
            _id:null,
            totalQty : { $sum:'$qty' },
        },
    }]);
    if(result.length>0)
    {
        res.send(result);
    }
    else{
        res.sendStatus(0);
    }
})

router.patch('/increment/:id',async(req,res)=>{
    const id = req.params.id;
    console.log(id);
    const option={new:true};
    const d = await getinfo.findById(id);
    d.qty = d.qty+1;
    res.send(d);
})

router.patch('/decrement/:id',async(req,res)=>{
    const id=req.params.id;
    const option = {new:true};
    const items = await getinfo.findById(id);
    if(items.qty > 0)
    {
        const items = await getinfo.findOneAndUpdate(id,{$inc:{qty:-1}},option);
        res.send(result);
    }
})

module.exports=router