const express = require('express')
const router = express.Router()
const orderinfo = require('../models/order_models')

router.post('/addorder',async(req,res)=>{
    const oentry = new getinfo({
        uname:req.body.name,
        phone:req.body.price,
        order:req.body.qty,
    })
    await ientry.save();
    res.send();
});

router.get('/dispOrder',async(req,res)=>{
    const data = await orderinfo.find();
    res.json(data)
});

module.exports=router