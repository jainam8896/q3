import React, { useEffect, useState } from 'react';
import axios from 'axios'
import { useNavigate } from 'react-router-dom'

const Client = () => {
    const [name, setname] = useState('');
    const [phone, setphone] = useState('');
    const [data, setdata] = useState([]);
    const [totalprice, setprice] = useState('');
    const [totalqty, setqty] = useState('');

    useEffect(() => {
        getdata();
    }, []);
    const getdata = async () => {
        try {
            const res = await axios.get('http://localhost:3004/item/dispitem');
            setdata(res.data);
            const totalq = await axios.get('http://localhost:3004/item/totalqty');
            setqty(totalq.data[0].totalqty);
            let total = 0;
            res.data.map((items) => {
                total += (items.price * items.qty);
            })
            setprice(total)
        }
        catch (err) {
            console.error(err);
        }
    }
    function oqty(e, s, id) {
        e.preventDefault();
        setdata(data.map((p) => {
            if (p._id === id) {
                if (e.target.id === "+") {
                    return { ...s, qty: s.qty + 1 };
                }
                else if (e.target.id === "-") {
                    if (p.qty > 0) {
                        return { ...s, qty: s.qty - 1 };
                    } else {
                        return p;
                    }
                }
            }
            else {
                return p;
            }
        }))
    }

    const handleName = (e) => {
        setname(e.target.value)
    }
    const handlephone = (e) => {
        setphone(e.target.value)
    }
    const collectData = async () => {
        try {
            const order = data;
            const insertdata = await axios.post('http://localhost:3004/order/addorder', { name, phone, order });
        }
        catch (error) {
            console.log("Error");
        }
    }
    let total = 0;
    const dispitems = data.map((p) => {
        total += p.qty * p.price;
        return (
            <div>
                <tr>
                    <td>{p.name}</td>
                    <td>{p.price}</td>
                    <td>{p.qty}</td>
                    <td>{p.qty * p.price}</td>
                    <td>
                        <button type="button" className='btn btn-outline-success me-3' id='+' onClick={(e) => oqty(e, p, p._id)}>+</button>
                        <button type="button" className='btn btn-outline-danger me-3' id='-' onClick={(e) => oqty(e, p, p._id)}>-</button>
                    </td>
                </tr>
            </div>
        )
    })

    return (
        <div>
            <br /><center>
                <br /><br />
                <hr/>
                <h4>Billing System</h4>
                <hr />
                <table class="table">
                    <thead>
                        <tr>
                            <th scope='col'>Items</th>
                            <th scope='col'>Price</th>
                            <th scope='col'>qty</th>
                            <th scope='col'>Total price</th>
                            <th scope='col'>Total qty</th>
                        </tr>
                    </thead>
                    <tbody>
                        {dispitems}
                        <tr>
                            <td colSpan={3}>Total billing</td>
                            <td>{total}</td>
                        </tr>
                    </tbody>
                </table>
                <div className='card w-50 mt-5 ms-5 bg-dark text-light'>
                    <div className='container-fluid mb-2'>
                        <div>
                            <h3>Insert Data</h3>
                            <div className='mb-3'>
                                {/* <label>Name :</label> */}
                                <input type="text" className='form-control' name='name' placeholder='Enter Your Name' required onChange={(e) => handleName(e)} /><br />
                            </div>
                            <div className='mb-3'>
                                {/* <label>Phone :</label> */}
                                <input type="text" className='form-control' name='name' placeholder='Enter Your Phone Number' required onChange={(e) => handlephone(e)} /><br />
                            </div>
                            <button type='button' className='btn btn-outline-success' onClick={collectData}>Submit</button>
                        </div>
                    </div>
                </div>
            </center>
        </div>
    );
}

export default Client
