import React, { useEffect, useState } from 'react';
import axios from 'axios'

const Display = () => {
    const [data, setdata] = useState([])
    useEffect(() => {
        getData();
    }, [])
    const getData = async () => {
        try {
            const res = await axios.get('http://localhost:3004/order/dispOrder');
            setdata(res.data);
        }
        catch (err) {
            console.error(err);
        }
    }
    let no = 0;
    return (
        <div>
            <div className='container w-100'>
                <br />
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Name</th>
                            <th scope="col">Phone</th>
                            <th scope="col">Order</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            data.map((d) => {
                                var total = 0;
                                return (
                                    <tr>
                                        <th scope="row">{++no}</th>
                                        <td>{d.uname}</td>
                                        <td>{d.phone}</td>
                                        <td>
                                            <table>
                                                <tr>
                                                    <th scope="col">Item</th>
                                                    <th scope="col">Price</th>
                                                    <th scope="col">Qty</th>
                                                    <th scope="col">Total Price</th>
                                                </tr>
                                                {d.order.map((o) => {
                                                    total += o.qty * o.price;
                                                    return (
                                                        <tr>
                                                            <td>{o.name}</td>
                                                            <td>{o.price}</td>
                                                            <td>{o.qty}</td>
                                                            <td>{o.qty * o.price}</td>
                                                        </tr>
                                                    )
                                                })}
                                                <tr>
                                                    <td colSpan={3}>Total billing</td>
                                                    <td>{total}</td>
                                                </tr>
                                            </table>
                                        </td>
                                    </tr>
                                )
                            })
                        }
                    </tbody>
                </table>
            </div>
        </div>
    );
}

export default Display
