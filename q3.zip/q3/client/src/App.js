import './App.css';
import Client from './comp/Client';
import Navbar from './comp/Navbar';
import { Route,Routes } from 'react-router';
import Display from './comp/Display';

function App() {
  return (
    <div>
      <Navbar/>
      <Routes>
        <Route path="/" element={<Client />}>Insert</Route>
        <Route path="/display" element={<Display />}>Insert</Route>
      </Routes>
    </div>
  );
}

export default App;
